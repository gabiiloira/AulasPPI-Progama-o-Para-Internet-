package com.example.notinhas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = openOrCreateDatabase("minhasnotinhas", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS notas (id INTEGER PRIMARY KEY AUTOINCREMENT,txt VARCHAR);");

        //String s = " \" ;DROP DATABSE";
        //db.execSQL("INSERT INTO notas VALUES (defaults, \"" +s +"\")"   );

        ContentValues cv=new ContentValues();
        cv.put("txt", "Baunilha");
        db.insert("notas", null, cv);
    }
}